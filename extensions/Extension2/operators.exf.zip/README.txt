This file is not meant to be opened!
Be careful as you can permanently break your extension!